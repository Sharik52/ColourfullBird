from itertools import cycle
import random
import sys
import pygame
from pygame.locals import *

FPS = 30
SCR_WIDTH = 600
SCR_HEIGHT = 512
# размер зазора между верхней и нижней трубами
PIPEGAPSIZE = 100
BASEY = SCR_HEIGHT * 0.79
IMAGES, SOUNDS, HITMASKS = {}, {}, {}

# список всех возможных птиц
BIRD_SPRITES = (
    # красная птица
    (
        'things_for_game/sprites/redbird-upflap.png',
        'things_for_game/sprites/redbird-midflap.png',
        'things_for_game/sprites/redbird-downflap.png',
    ),
    # синяя птица
    (
        'things_for_game/sprites/bluebird-upflap.png',
        'things_for_game/sprites/bluebird-midflap.png',
        'things_for_game/sprites/bluebird-downflap.png',
    ),
    # жёлтая птица
    (
        'things_for_game/sprites/yellowbird-upflap.png',
        'things_for_game/sprites/yellowbird-midflap.png',
        'things_for_game/sprites/yellowbird-downflap.png',
    ),
)

# картика заднего фона
BACKGROUNDS_SPRITE = 'things_for_game/sprites/background.jpg'


# список труб
PIPES_SPRITES = (
    'things_for_game/sprites/pipe-green.png',
    'things_for_game/sprites/pipe-red.png',
)


try:
    xrange
except NameError:
    xrange = range


def main():
    global SCREEN, FPSCLOCK
    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    SCREEN = pygame.display.set_mode((SCR_WIDTH, SCR_HEIGHT))
    pygame.display.set_caption('Flappy Bird')

    # картинки чисел для счета
    IMAGES['numbers'] = (
        pygame.image.load('things_for_game/sprites/0.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/1.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/2.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/3.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/4.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/5.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/6.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/7.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/8.png').convert_alpha(),
        pygame.image.load('things_for_game/sprites/9.png').convert_alpha()
    )

    # картинка конца игры
    IMAGES['gameover'] = pygame.image.load('things_for_game/sprites/gameover.png').convert_alpha()
    # картинка для начального экрана
    IMAGES['message'] = pygame.image.load('things_for_game/sprites/message.png').convert_alpha()
    # картинка земли
    IMAGES['base'] = pygame.image.load('things_for_game/sprites/base.png').convert_alpha()

    # звуки
    if 'win' in sys.platform:
        soundExt = '.wav'
    else:
        soundExt = '.ogg'

    SOUNDS['die']    = pygame.mixer.Sound('things_for_game/audio/die' + soundExt)
    SOUNDS['hit']    = pygame.mixer.Sound('things_for_game/audio/hit' + soundExt)
    SOUNDS['point']  = pygame.mixer.Sound('things_for_game/audio/point' + soundExt)
    SOUNDS['swoosh'] = pygame.mixer.Sound('things_for_game/audio/swoosh' + soundExt)
    SOUNDS['wing']   = pygame.mixer.Sound('things_for_game/audio/wing' + soundExt)

    while True:
        # присваивание пременной для заднего фона
        IMAGES['background'] = pygame.image.load(BACKGROUNDS_SPRITE).convert()

        # присваивание картинки для птицы
        randPlayer = random.randint(0, len(BIRD_SPRITES) - 1)
        IMAGES['player'] = (
            pygame.image.load(BIRD_SPRITES[randPlayer][0]).convert_alpha(),
            pygame.image.load(BIRD_SPRITES[randPlayer][1]).convert_alpha(),
            pygame.image.load(BIRD_SPRITES[randPlayer][2]).convert_alpha(),
        )

        # присваивание картинки для трубы
        pipeindex = random.randint(0, len(PIPES_SPRITES) - 1)
        IMAGES['pipe'] = (
            pygame.transform.flip(
                pygame.image.load(PIPES_SPRITES[pipeindex]).convert_alpha(), False, True),
            pygame.image.load(PIPES_SPRITES[pipeindex]).convert_alpha(),
        )

        # поле удара для трубы
        HITMASKS['pipe'] = (
            GETTING_HITMASKS(IMAGES['pipe'][0]),
            GETTING_HITMASKS(IMAGES['pipe'][1]),
        )

        # поле удара для птицы
        HITMASKS['player'] = (
            GETTING_HITMASKS(IMAGES['player'][0]),
            GETTING_HITMASKS(IMAGES['player'][1]),
            GETTING_HITMASKS(IMAGES['player'][2]),
        )

        movementInfo = START_SCR()
        crashInfo = MAIN_EVENT(movementInfo)
        GAME_OVER_SCR(crashInfo)


def START_SCR():
    playerIndex = 0
    playerIndexGen = cycle([0, 1, 2, 1])
    loopIter = 0

    playerx = int(SCR_WIDTH * 0.2)
    playery = int((SCR_HEIGHT - IMAGES['player'][0].get_height()) / 2)

    messagex = int((SCR_WIDTH - IMAGES['message'].get_width()) / 2)
    messagey = int(SCR_HEIGHT * 0.12)

    basex = 0
    baseShift = IMAGES['base'].get_width() - IMAGES['background'].get_width()

    # для передвижения птицы вверх-вниз на стартовом экране
    playerShmVals = {'val': 0, 'dir': 1}

    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                # звук взмахов
                SOUNDS['wing'].play()
                return {
                    'playery': playery + playerShmVals['val'],
                    'basex': basex,
                    'playerIndexGen': playerIndexGen,
                }

        # настройка расположения птицы
        if (loopIter + 1) % 5 == 0:
            playerIndex = next(playerIndexGen)
        loopIter = (loopIter + 1) % 30
        basex = -((-basex + 4) % baseShift)
        BIRD_SHM(playerShmVals)

        # отрисовка картинок
        SCREEN.blit(IMAGES['background'], (0,0))
        SCREEN.blit(IMAGES['player'][playerIndex],
                    (playerx, playery + playerShmVals['val']))
        SCREEN.blit(IMAGES['message'], (messagex, messagey))
        SCREEN.blit(IMAGES['base'], (basex, BASEY))

        pygame.display.update()
        FPSCLOCK.tick(FPS)


def MAIN_EVENT(movementInfo):
    score = playerIndex = loopIter = 0
    playerIndexGen = movementInfo['playerIndexGen']
    playerx, playery = int(SCR_WIDTH * 0.2), movementInfo['playery']

    basex = movementInfo['basex']
    baseShift = IMAGES['base'].get_width() - IMAGES['background'].get_width()

    # присваивание труб переменными
    newPipe1 = GETTING_PIPES()
    newPipe2 = GETTING_PIPES()

    # список расположения верхних труб
    upperPipes = [
        {'x': SCR_WIDTH + 200, 'y': newPipe1[0]['y']},
        {'x': SCR_WIDTH + 200 + (SCR_WIDTH / 2), 'y': newPipe2[0]['y']},
    ]

    # список расположения нижних труб
    lowerPipes = [
        {'x': SCR_WIDTH + 200, 'y': newPipe1[1]['y']},
        {'x': SCR_WIDTH + 200 + (SCR_WIDTH / 2), 'y': newPipe2[1]['y']},
    ]

    dt = FPSCLOCK.tick(FPS)/1000
    pipeVelX = -128 * dt

    # скорости птицы
    # скорость вдоль Y
    playerVelY    =  -9
    # максимальная скорость полёта вниз
    playerMaxVelY =  10
    # минимальная скорость подъёма верх
    playerMinVelY =  -8
    # ускорение вниз
    playerAccY    =   1
    # ротация птицы
    playerRot     =  45
    # скорость под углом
    playerVelRot  =   3
    # максимальный поворот
    playerRotThr  =  20
    # скорость при взмахе
    playerFlapAcc =  -9
    # True если птица взмахивает крыльями
    playerFlapped = False


    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                if playery > -2 * IMAGES['player'][0].get_height():
                    playerVelY = playerFlapAcc
                    playerFlapped = True
                    SOUNDS['wing'].play()

        # проверка на удар
        crashTest = CHECKING_HIT({'x': playerx, 'y': playery, 'index': playerIndex},
                                 upperPipes, lowerPipes)
        if crashTest[0]:
            return {
                'y': playery,
                'groundCrash': crashTest[1],
                'basex': basex,
                'upperPipes': upperPipes,
                'lowerPipes': lowerPipes,
                'score': score,
                'playerVelY': playerVelY,
                'playerRot': playerRot
            }

        # проверка для смены счёта
        playerMidPos = playerx + IMAGES['player'][0].get_width() / 2
        for pipe in upperPipes:
            pipeMidPos = pipe['x'] + IMAGES['pipe'][0].get_width() / 2
            if pipeMidPos <= playerMidPos < pipeMidPos + 4:
                score += 1
                SOUNDS['point'].play()

        if (loopIter + 1) % 3 == 0:
            playerIndex = next(playerIndexGen)
        loopIter = (loopIter + 1) % 30
        basex = -((-basex + 100) % baseShift)

        if playerRot > -90:
            playerRot -= playerVelRot

        if playerVelY < playerMaxVelY and not playerFlapped:
            playerVelY += playerAccY
        if playerFlapped:
            playerFlapped = False
            playerRot = 45

        playerHeight = IMAGES['player'][playerIndex].get_height()
        playery += min(playerVelY, BASEY - playery - playerHeight)

        # движение труб влево
        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            # движение левой трубы
            uPipe['x'] += pipeVelX
            # движение правой трубы
            lPipe['x'] += pipeVelX

        # добавление новых труб
        if 3 > len(upperPipes) > 0 and 0 < upperPipes[0]['x'] < 5:
            newPipe = GETTING_PIPES()
            # добавление верхней трубы
            upperPipes.append(newPipe[0])
            # добавление нижней трубы
            lowerPipes.append(newPipe[1])

        # удаление труб
        if len(upperPipes) > 0 and upperPipes[0]['x'] < -IMAGES['pipe'][0].get_width():
            # удаление верхней трубы
            upperPipes.pop(0)
            # удаление нижней трубы
            lowerPipes.pop(0)

        # отрисовка картинки
        SCREEN.blit(IMAGES['background'], (0,0))

        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            SCREEN.blit(IMAGES['pipe'][0], (uPipe['x'], uPipe['y']))
            SCREEN.blit(IMAGES['pipe'][1], (lPipe['x'], lPipe['y']))

        SCREEN.blit(IMAGES['base'], (basex, BASEY))
        SCORE(score)

        visibleRot = playerRotThr
        if playerRot <= playerRotThr:
            visibleRot = playerRot
        
        playerSurface = pygame.transform.rotate(IMAGES['player'][playerIndex], visibleRot)
        SCREEN.blit(playerSurface, (playerx, playery))

        pygame.display.update()
        FPSCLOCK.tick(FPS)


def GAME_OVER_SCR(crashInfo):
    score = crashInfo['score']
    playerx = SCR_WIDTH * 0.2
    playery = crashInfo['y']
    playerHeight = IMAGES['player'][0].get_height()
    playerVelY = crashInfo['playerVelY']
    playerAccY = 2
    playerRot = crashInfo['playerRot']
    playerVelRot = 7

    basex = crashInfo['basex']

    upperPipes, lowerPipes = crashInfo['upperPipes'], crashInfo['lowerPipes']

    # воспроизведение звуков удара и смерти
    SOUNDS['hit'].play()
    if not crashInfo['groundCrash']:
        SOUNDS['die'].play()

    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                if playery + playerHeight >= BASEY - 1:
                    return

        # передвижение по Y птицы
        if playery + playerHeight < BASEY - 1:
            playery += min(playerVelY, BASEY - playery - playerHeight)

        if playerVelY < 15:
            playerVelY += playerAccY

        if not crashInfo['groundCrash']:
            if playerRot > -90:
                playerRot -= playerVelRot

        # отрисовка картинки
        SCREEN.blit(IMAGES['background'], (0,0))

        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            SCREEN.blit(IMAGES['pipe'][0], (uPipe['x'], uPipe['y']))
            SCREEN.blit(IMAGES['pipe'][1], (lPipe['x'], lPipe['y']))

        SCREEN.blit(IMAGES['base'], (basex, BASEY))
        SCORE(score)

        playerSurface = pygame.transform.rotate(IMAGES['player'][1], playerRot)
        SCREEN.blit(playerSurface, (playerx,playery))
        SCREEN.blit(IMAGES['gameover'], (210, 180))

        FPSCLOCK.tick(FPS)
        pygame.display.update()


def BIRD_SHM(playerShm):
    if abs(playerShm['val']) == 8:
        playerShm['dir'] *= -1

    if playerShm['dir'] == 1:
         playerShm['val'] += 1
    else:
        playerShm['val'] -= 1


def GETTING_PIPES():
    # Y зазора между верхней и нижней трубами
    gapY = random.randrange(0, int(BASEY * 0.6 - PIPEGAPSIZE))
    gapY += int(BASEY * 0.2)
    pipeHeight = IMAGES['pipe'][0].get_height()
    pipeX = SCR_WIDTH + 10

    return [
        # верхняя труба
        {'x': pipeX, 'y': gapY - pipeHeight},
        # нижняя труба
        {'x': pipeX, 'y': gapY + PIPEGAPSIZE},
    ]


def SCORE(score):
    scoreDigits = [int(x) for x in list(str(score))]
    # размер чисел счёта
    totalWidth = 0

    for digit in scoreDigits:
        totalWidth += IMAGES['numbers'][digit].get_width()

    Xoffset = (SCR_WIDTH - totalWidth) / 2

    for digit in scoreDigits:
        SCREEN.blit(IMAGES['numbers'][digit], (Xoffset, SCR_HEIGHT * 0.1))
        Xoffset += IMAGES['numbers'][digit].get_width()


def CHECKING_HIT(player, upperPipes, lowerPipes):
    pi = player['index']
    player['w'] = IMAGES['player'][0].get_width()
    player['h'] = IMAGES['player'][0].get_height()

    # при ударе птицы об землю
    if player['y'] + player['h'] >= BASEY - 1:
        return [True, True]
    else:

        playerRect = pygame.Rect(player['x'], player['y'],
                      player['w'], player['h'])
        pipeW = IMAGES['pipe'][0].get_width()
        pipeH = IMAGES['pipe'][0].get_height()

        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            # верхняяя и нижняя трубы
            uPipeRect = pygame.Rect(uPipe['x'], uPipe['y'], pipeW, pipeH)
            lPipeRect = pygame.Rect(lPipe['x'], lPipe['y'], pipeW, pipeH)

            # зона удара птицы
            pHitMask = HITMASKS['player'][pi]
            # зона удара верзней трубы
            uHitmask = HITMASKS['pipe'][0]
            # зона удара нижней трубы
            lHitmask = HITMASKS['pipe'][1]

            # при столкновении птицы с верхней трубой
            uCollide = PIXEL_COLLISION(playerRect, uPipeRect, pHitMask, uHitmask)
            # при столкновении птицы с нижней трубой
            lCollide = PIXEL_COLLISION(playerRect, lPipeRect, pHitMask, lHitmask)

            if uCollide or lCollide:
                return [True, False]

    return [False, False]

def PIXEL_COLLISION(rect1, rect2, hitmask1, hitmask2):
    rect = rect1.clip(rect2)

    if rect.width == 0 or rect.height == 0:
        return False

    x1, y1 = rect.x - rect1.x, rect.y - rect1.y
    x2, y2 = rect.x - rect2.x, rect.y - rect2.y

    for x in xrange(rect.width):
        for y in xrange(rect.height):
            if hitmask1[x1+x][y1+y] and hitmask2[x2+x][y2+y]:
                return True
    return False

def GETTING_HITMASKS(image):
    mask = []
    for x in xrange(image.get_width()):
        mask.append([])
        for y in xrange(image.get_height()):
            mask[x].append(bool(image.get_at((x,y))[3]))
    return mask

if __name__ == '__main__':
    main()